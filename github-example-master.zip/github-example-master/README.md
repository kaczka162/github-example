GitHub Example
==============

This is a simple example repository that will be used to show how to get started with GitHub.

How to Contribute
=================

Just fork the original repo at pragmaticlearning/github-example, make your changes and send over a Pull Request.
